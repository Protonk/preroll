# Preroll package

One function. Pretty simple. 

You can install it with devtools by typing `install_github("preroll", "Protonk")`. alternately you can clone the repo and open it up in R Studio and build a local package with the build tab. Or you can use R CMD INSTALL. with the supplied gzipped source. 

